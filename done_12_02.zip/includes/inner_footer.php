<footer id="footer" class="footer-dark text-light container-fluid">
    <div class="footer-inner wrapper row">

        <div class="clearfix">
        <div class="col-md-3">
             <div class="widget">
                 <img src="img/logo_footer.png" srcset="img/logo_footer.png 1x, img/logo_footer.png 2x" alt="Jaabaz" class="footer-logo">
                 <div class="spacer-mini"></div>
             </div>

             <div class="widget social-footer-div">
                <ul class="socialmedia-widget hover-fade-1">
                    <li class="facebook"><a href="#"></a></li>
                    <li class="twitter"><a href="#"></a></li>
                    <li class="dribbble"><a href="#"></a></li>
                    <li class="behance"><a href="#"></a></li>
                    <li class="instagram"><a href="#"></a></li>
                </ul>
            </div>

        </div>
        <div class="col-md-6">
           <div class="fb-page" data-href="https://www.facebook.com/teamjaabaz/" data-width="500" data-height="450" data-small-header="false" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="false"><blockquote cite="https://www.facebook.com/teamjaabaz/" class="fb-xfbml-parse-ignore"><a href="https://www.facebook.com/teamjaabaz/">TEAM JAABAZ</a></blockquote></div>
       </div>
       <div class="col-md-2">
          
           <div class="footer-acm-div">
             <img class="acmlogo-footer" src="img/acm.png">
             <div class="acm-text">&copy; Developed by ACM-VIT</div>
         </div>
     </div>
 </div>
</div>
</footer>