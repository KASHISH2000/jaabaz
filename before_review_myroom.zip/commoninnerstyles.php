<link rel="stylesheet" type="text/css" href="../styles/animate.css">
<link rel="stylesheet" type="text/css" href="../styles/commoninner.css">
   <link rel="stylesheet" type="text/css" href="../styles/ionicons.min.css">