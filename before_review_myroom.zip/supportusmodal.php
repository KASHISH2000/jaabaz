<div class="modal-content" id="supportus">
	<div class="modal-headerr" style="padding: 10px;">
		<br>
		<button type="button" class="close" data-dismiss="modal" style="color:#fff !important;"><i class="ion-close-round" style="color:#fff !important;"></i>&nbsp;&nbsp;</button>
		<h1 class="modal-title text-center">Support Us</h1>
	</div>
	<div class="modal-body">
		<div class="container">
		</div>
	</div>
	<div class="modal-footerr text-center">
	<hr class="white-hr">
		<button type="button" class="btn btn-default font-black" data-dismiss="modal">Close</button>
	</div>
</div>
