
<?php
 //       ["Full Nam","Department","image","FB LINK","linked in","email id"]
/*Team leaders 0-2*/
$team_leaders[0]=["Bhuvanesh Jain","Team Captain","bhuvanesh","https://www.facebook.com/bhuvanesh.jain.1
","https://www.linkedin.com/in/bhuvanesh-jain-081427109","bhuvaneshjain96@gmail.com"];
$team_leaders[]=["Som Dwivedi","Team Vice Captain","som","https://www.facebook.com/som.dwivedi1","http://linkedin.com/in/som-d-7b404ba6","somdwivedi1411@gmail.com"];
$team_leaders[]=["Harikrishna","Team Manager","harikrishna","https://www.facebook.com/hari.pansuriya.3","https://linkedin.com/in/harikrishna-pansuriya-59040a9a","harikrishnapansuriya@yahoo.com"];

/*Vehicle Dynamics 7-15*/
$team_vehicle[0]=["Aditya G","Vehicle Dynamics Lead","adityag","https://www.facebook.com/aditya.gangishetty","https://www.linkedin.com/in/aditya-gangishetty-252b7bba","gangishettyaditya@gmail.com"];
$team_vehicle[]=["Prithvesh Ashok","Steering Lead","prithvesh","https://www.facebook.com/prithveshashok","https://www.linkedin.com/in/prithvesh-ashok","prithveshashok@rocketmail.com"];
$team_vehicle[]=["Shubham Singh","Vehicle Dynamics","shubham","https://www.facebook.com/profile.php?id=100002287074105","https://www.linkedin.com/in/shubham-singh-676804112","shubhamvsingh97@gmail.com"];
$team_vehicle[]=["Yash Jajoo","Vehicle Dynamics","yash","https://www.facebook.com/yash.jajoo.31","https://www.linkedin.com/in/yash-jajoo-096489118/","yashjajoo06@gmail.com"];
$team_vehicle[]=["Pulkit Sharma","Vehicle Dynamics","pulkit","https://www.facebook.com/pfamily.sharma","https://www.linkedin.com/profile/view?id=552839002","pulkit.sharma2015@vit.ac.in"];
$team_vehicle[]=["Lakshya","Vehicle Dynamics","lakshya","https://www.facebook.com/lakshyajhalani09","https://www.linkedin.com/in/lakshya-jhalani-76b1b8135","lakshya.jhalani2015@vit.ac.in"];
$team_vehicle[]=["Shreyas Shankar","Vehicle Dynamics","shreyas","https://www.facebook.com/shrezshank","https://www.linkedin.com/in/shreyas-shanker-80453611b","shanker.shreyas@gmail.com"];
$team_vehicle[]=["Tanay","Vehicle Dynamics","tanay","https://www.facebook.com/tanay.hari","http://linkedin.com/in/tanay-hariprasad-16747811b","haritanay555@gmail.com"];
$team_vehicle[]=["Arun Kumar","Vehicle Dynamics","arun","https://m.facebook.com/arun.arunoi?ref=bookmarks","http://linkedin.com/in/arun-kumar-murthy-039b5612b","arunkumarmurthy7@gmail.com"];

/*Transmission*/
$team_transmission[0]=["Manikandan Sridhar","Transmisssion Lead","manikandan","https://www.facebook.com/mkandan09","https://www.linkedin.com/in/manikandan-sridhar-876aa0b6","mkandans9896@gmail.com"];
$team_transmission[]=["Priyank Agarwal","Manufacturing Lead","priyank","https://www.facebook.com/priyank.agarwal.1023","https://www.linkedin.com/in/priyank-agarwal-141a50105/","priyank.agarwal96@gmail.com"];
$team_transmission[]=["Felix Joseph","Transmisssion","felix","https://www.facebook.com/felixjrover","https://www.linkedin.com/in/felix-joseph-a34267121","felix.joseph2015@vit.ac.in"];
$team_transmission[]=["Nikhil","Transmisssion","nikhil","https://www.facebook.com/nikhil.kumar.1238","https://www.linkedin.com/in/nikhil-kumar-356b58103","nikilmys@gmail.com"];
$team_transmission[]=["Palash","Transmisssion","palash","https://www.facebook.com/palash.agrawal.7161","http://www.linkedin.com/in/palash-agrawal-a6681b123","palashagrawal18@gmail.com"];
$team_transmission[]=["Chiranjeev Solanki","Transmisssion","chiranjeev"," https://www.facebook.com/chiranjeev.solanki","https://www.linkedin.com/in/chiranjeev-solanki-685123135","chiranjeev.solanki@gmail.com"];
$team_transmission[]=["Himanvesh","Transmisssion","himanvesh","https://www.facebook.com/himanvesh","https://www.linkedin.com/in/himanvesh-naidu-05ab49a8/","himanveshnaidu.m2015@vit.ac.in"];


/*Marketing and Management-*/
$team_marketing[0]=["Deva Harsha","Public Relations","deva","https://www.facebook.com/furiousharsha","https://www.linkedin.com/in/deva-harsha-yarlagadda-9749b0b6","devaharshay@gmail.com"];
$team_marketing[]=["Tuhin Sharma","Marketing and Management","tuhin","https://www.facebook.com/tuhin.sharma.5","https://www.linkedin.com/in/tuhin-sharma-2739025a","tuhin.sharma2015@vit.ac.in"];
$team_marketing[]=["Divyansh","Marketing and Management","divyansh","https://www.facebook.com/divyansh.chandaniha","https://www.linkedin.com/in/divyansh-chandaniha-673aa2111","kaikuro@gmail.com"];
$team_marketing[]=["Arizul Islam","Marketing and Management","arizul","https://m.facebook.com/arizul.islam?ref=bookmarks","https://in.linkedin.com/in/arizul-islam-48215a102","arry2749@gmail.com"];
$team_marketing[]=["Sameer","Marketing and Management","sameer","http://fb.com","https://www.linkedin.com/",""];
$team_marketing[]=["Sanjay","Marketing and Management","sanjay","https://www.facebook.com/sameer.bharadwaj.589","https://www.linkedin.com/","sameerj.bharadwaj2015@vit.ac.in"];
$team_marketing[]=["Aditya","Marketing and Management","aditya","https://www.facebook.com/aditya.paranthaman","https://linkedin.com/in/aditya-paranthaman-6a0545b5","aditya.paranthaman2015@vit.ac.in "];
$team_marketing[]=["Kaustabh","Marketing and Management","kaustabh","https://www.facebook.com/kaustubh.kalyankar","https://www.linkedin.com/in/kaustubh-kalyankar-35a193135","potatosmuggler1@gmail.com"];

/*Designs 3-6*/
$team_design[0]=["Parth Deshpande","Design Lead","parth","https://www.facebook.com/parth.deshpande.94","https://www.linkedin.com/in/parth-deshpande-38142b109","parthdeshpande3@gmail.com"];
$team_design[]=["Aayush Jain","Design","aayush","https://www.facebook.com/jainaayush2006","https://www.linkedin.com/in/aayush-jain-828ba9134","jainaayush2006@gmail.com"];
$team_design[]=["Suhas H G","Design","suhas"," https://www.facebook.com/suhas.hg.31 ","https://www.linkedin.com/in/suhas-h-g-b77504113?trk=hp-identity-name","suhashg97@gmail.com"];
$team_design[]=["Vignesh","Design","vignesh","https://www.facebook.com/vickynesh97","http://www.linkedin.com/in/vigneshwar-venkatesan-56311a135","vicky.venky@gmail.com"];

/*Brakes*/
$team_brakes[0]=["Rishikesh Joshi","Brakes Lead","rishikesh","https://www.facebook.com/rjoshi17","https://www.linkedin.com/in/rishikesh-joshi-95abab134/","rishikeshsjoshi@gmail.com"];
$team_brakes[]=["Dhruv","Brakes","dhruv","https://m.facebook.com/profile.php?ref=bookmarks","https://www.linkedin.com/in/dhruv-manchanda-09aba8134?trk=nav_responsive_tab_profile","dhruvmanchanda15@gmail.com"];
$team_brakes[]=["Yashaswi","Brakes","yashaswi","https://www.facebook.com/yashaswi.arora","https://www.linkedin.com/in/yashaswi-arora-910bbb134","yashaswi.2015@vit.ac.in"];
$team_brakes[]=["Naman","Brakes","naman","https://m.facebook.com/namans05","https://www.linkedin.com/in/naman-soni-a36a25118/","namansoni05@gmail.com"];

/*Steering*/
/*Manufacturing*/
$team_manufacturing[0]=["Som Dwivedi","Electrical Lead","som","https://www.facebook.com/som.dwivedi1","http://linkedin.com/in/som-d-7b404ba6","somdwivedi1411@gmail.com"];

/*Electrical*/
$team_manufacturing[]=["Rutwij","Electrical","rutwij","https://m.facebook.com/rutwijbapat?ref=bookmarks","https://www.linkedin.com/in/rutwij-bapat-734000135","rutwijbapat123@gmail.com"];
?>
<div class="modal-content">
	<div class="modal-headerr" style="padding: 10px;">
		<br>
		<button type="button" class="close"  onclick="gotomeettheteam();" data-dismiss="modal" style="color:#fff !important;"><i class="ion-close-round"></i>&nbsp;&nbsp;</button>
		<h1 class="modal-title text-center">Team 2017</h1>
	</div>
	<div class="modal-body">
		<div class="container">
			<div class="row">
				<ul class="ch-grid">
					<?php
					$i=0;
					for($i=0;$i<count($team_leaders);$i++)
					{
						$name=$team_leaders[$i][0];
						$dept=$team_leaders[$i][1];
						$img=$team_leaders[$i][2];
						$fb=$team_leaders[$i][3];
						$ll=$team_leaders[$i][4];
						$email=$team_leaders[$i][5];
						?>
						<div class="col-xs-6 col-sm-3 col-md-2 boxcol box-col">
							<div class="ch-item ch-img-1 box" style="background-image: url('../img/team17/<?php echo $img;?>.JPG');">
								<div class="ch-info">
									<h3><?php echo $name;?></h3>
									<a href="mailto:<?php echo $email;?>"><h5 class="ch-info-email"><?php echo $email;?></h5></a>
									<div class="ch-social-div">	
										<a href="<?php echo $fb ;?>" target="_blank"><i class="ionclass ion-social-facebook" aria-hidden="true"></i></a>&nbsp;&nbsp;&nbsp;<a href="<?php echo $ll ;?>" target="_blank"><i class="ionclass ionclass-ll ion-social-linkedin" aria-hidden="true"></i></a>
									</div>
								</div>
							</div>
							<h3 class="text-center"><?php echo $dept;?></h3>

						</div>
						<?php
					}
					?>
				</ul>
			</div>
			<hr class="thoda-light">
			<div class="row">
				<ul class="ch-grid">
					<?php
					$i=0;
					for($i=0;$i<count($team_vehicle);$i++)
					{
						$name=$team_vehicle[$i][0];
						$dept=$team_vehicle[$i][1];
						$img=$team_vehicle[$i][2];
						$fb=$team_vehicle[$i][3];
						$ll=$team_vehicle[$i][4];
						$email=$team_vehicle[$i][5];
						?>
						<div class="col-xs-6 col-sm-3 col-md-2 boxcol box-col">
							<div class="ch-item ch-img-1 box" style="background-image: url('../img/team17/<?php echo $img;?>.JPG');">
								<div class="ch-info">
									<h3><?php echo $name;?></h3>
									<a href="mailto:<?php echo $email;?>"><h5 class="ch-info-email"><?php echo $email;?></h5></a>
									<div class="ch-social-div">	
										<a href="<?php echo $fb ;?>" target="_blank"><i class="ionclass ion-social-facebook" aria-hidden="true"></i></a>&nbsp;&nbsp;&nbsp;<a href="<?php echo $ll ;?>" target="_blank"><i class="ionclass ionclass-ll ion-social-linkedin" aria-hidden="true"></i></a>
									</div>
								</div>
							</div>
							<h3 class="text-center"><?php echo $dept;?></h3>

						</div>
						<?php
					}
					?>
				</ul>
			</div>
			<hr class="thoda-light">
			<div class="row">
				<ul class="ch-grid">
					<?php
					$i=0;
					for($i=0;$i<count($team_transmission);$i++)
					{
						$name=$team_transmission[$i][0];
						$dept=$team_transmission[$i][1];
						$img=$team_transmission[$i][2];
						$fb=$team_transmission[$i][3];
						$ll=$team_transmission[$i][4];
						$email=$team_transmission[$i][5];
						?>
						<div class="col-xs-6 col-sm-3 col-md-2 boxcol box-col">
							<div class="ch-item ch-img-1 box" style="background-image: url('../img/team17/<?php echo $img;?>.JPG');">
								<div class="ch-info">
									<h3><?php echo $name;?></h3>
									<a href="mailto:<?php echo $email;?>"><h5 class="ch-info-email"><?php echo $email;?></h5></a>
									<div class="ch-social-div">	
										<a href="<?php echo $fb ;?>" target="_blank"><i class="ionclass ion-social-facebook" aria-hidden="true"></i></a>&nbsp;&nbsp;&nbsp;<a href="<?php echo $ll ;?>" target="_blank"><i class="ionclass ionclass-ll ion-social-linkedin" aria-hidden="true"></i></a>
									</div>
								</div>
							</div>
							<h3 class="text-center"><?php echo $dept;?></h3>

						</div>
						<?php
					}
					?>
				</ul>
			</div>
			<hr class="thoda-light">
			<div class="row">
				<ul class="ch-grid">
					<?php
					$i=0;
					for($i=0;$i<count($team_marketing);$i++)
					{
						$name=$team_marketing[$i][0];
						$dept=$team_marketing[$i][1];
						$img=$team_marketing[$i][2];
						$fb=$team_marketing[$i][3];
						$ll=$team_marketing[$i][4];
						$email=$team_marketing[$i][5];
						?>
						<div class="col-xs-6 col-sm-3 col-md-2 boxcol box-col">
							<div class="ch-item ch-img-1 box" style="background-image: url('../img/team17/<?php echo $img;?>.JPG');">
								<div class="ch-info">
									<h3><?php echo $name;?></h3>
									<a href="mailto:<?php echo $email;?>"><h5 class="ch-info-email"><?php echo $email;?></h5></a>
									<div class="ch-social-div">	
										<a href="<?php echo $fb ;?>" target="_blank"><i class="ionclass ion-social-facebook" aria-hidden="true"></i></a>&nbsp;&nbsp;&nbsp;<a href="<?php echo $ll ;?>" target="_blank"><i class="ionclass ionclass-ll ion-social-linkedin" aria-hidden="true"></i></a>
									</div>
								</div>
							</div>
							<h3 class="text-center"><?php echo $dept;?></h3>

						</div>
						<?php
					}
					?>
				</ul>
			</div>
			<hr class="thoda-light">
			<div class="row">
				<ul class="ch-grid">
					<?php
					$i=0;
					for($i=0;$i<count($team_design);$i++)
					{
						$name=$team_design[$i][0];
						$dept=$team_design[$i][1];
						$img=$team_design[$i][2];
						$fb=$team_design[$i][3];
						$ll=$team_design[$i][4];
						$email=$team_design[$i][5];
						?>
						<div class="col-xs-6 col-sm-3 col-md-2 boxcol box-col">
							<div class="ch-item ch-img-1 box" style="background-image: url('../img/team17/<?php echo $img;?>.JPG');">
								<div class="ch-info">
									<h3><?php echo $name;?></h3>
									<a href="mailto:<?php echo $email;?>"><h5 class="ch-info-email"><?php echo $email;?></h5></a>
									<div class="ch-social-div">	
										<a href="<?php echo $fb ;?>" target="_blank"><i class="ionclass ion-social-facebook" aria-hidden="true"></i></a>&nbsp;&nbsp;&nbsp;<a href="<?php echo $ll ;?>" target="_blank"><i class="ionclass ionclass-ll ion-social-linkedin" aria-hidden="true"></i></a>
									</div>
								</div>
							</div>
							<h3 class="text-center"><?php echo $dept;?></h3>

						</div>
						<?php
					}
					?>
				</ul>
			</div>
			<hr class="thoda-light">
			<div class="row">
				<ul class="ch-grid">
					<?php
					$i=0;
					for($i=0;$i<count($team_brakes);$i++)
					{
						$name=$team_brakes[$i][0];
						$dept=$team_brakes[$i][1];
						$img=$team_brakes[$i][2];
						$fb=$team_brakes[$i][3];
						$ll=$team_brakes[$i][4];
						$email=$team_brakes[$i][5];
						?>
						<div class="col-xs-6 col-sm-3 col-md-2 boxcol box-col">
							<div class="ch-item ch-img-1 box" style="background-image: url('../img/team17/<?php echo $img;?>.JPG');">
								<div class="ch-info">
									<h3><?php echo $name;?></h3>
									<a href="mailto:<?php echo $email;?>"><h5 class="ch-info-email"><?php echo $email;?></h5></a>
									<div class="ch-social-div">	
										<a href="<?php echo $fb ;?>" target="_blank"><i class="ionclass ion-social-facebook" aria-hidden="true"></i></a>&nbsp;&nbsp;&nbsp;<a href="<?php echo $ll ;?>" target="_blank"><i class="ionclass ionclass-ll ion-social-linkedin" aria-hidden="true"></i></a>
									</div>
								</div>
							</div>
							<h3 class="text-center"><?php echo $dept;?></h3>

						</div>
						<?php
					}
					?>
				</ul>
			</div>
			<!-- <hr class="thoda-light">
			<div class="row">
				<ul class="ch-grid">
					<?php
					$i=0;
					for($i=0;$i<count($team_steering);$i++)
					{
						$name=$team_steering[$i][0];
						$dept=$team_steering[$i][1];
						$img=$team_steering[$i][2];
						$fb=$team_steering[$i][3];
						$ll=$team_steering[$i][4];
						$email=$team_leaders[$i][5];
						?>
						<div class="col-xs-6 col-sm-3 col-md-2 boxcol box-col">
							<div class="ch-item ch-img-1 box" style="background-image: url('../img/team17/<?php echo $img;?>.JPG');">
								<div class="ch-info">
									<h3><?php echo $name;?></h3>
									<div class="ch-social-div">	
									<a href="<?php echo $fb ;?>" target="_blank"><i class="ionclass ion-social-facebook" aria-hidden="true"></i></a>
									</div>
								</div>
							</div>
							<h3 class="text-center"><?php echo $dept;?></h3>

						</div>
						<?php
					}
					?>
				</ul>
			</div> -->
			<hr class="thoda-light">
			<div class="row">
				<ul class="ch-grid">
					<?php
					$i=0;
					for($i=0;$i<count($team_manufacturing);$i++)
					{
						$name=$team_manufacturing[$i][0];
						$dept=$team_manufacturing[$i][1];
						$img=$team_manufacturing[$i][2];
						$fb=$team_manufacturing[$i][3];
						$ll=$team_manufacturing[$i][4];
						$email=$team_manufacturing[$i][5];
						?>
						<div class="col-xs-6 col-sm-3 col-md-2 boxcol box-col">
							<div class="ch-item ch-img-1 box" style="background-image: url('../img/team17/<?php echo $img;?>.JPG');">
								<div class="ch-info">
									<h3><?php echo $name;?></h3>
									<a href="mailto:<?php echo $email;?>"><h5 class="ch-info-email"><?php echo $email;?></h5></a>
									<div class="ch-social-div">	
										<a href="<?php echo $fb ;?>" target="_blank"><i class="ionclass ion-social-facebook" aria-hidden="true"></i></a>&nbsp;&nbsp;&nbsp;<a href="<?php echo $ll ;?>" target="_blank"><i class="ionclass ionclass-ll ion-social-linkedin" aria-hidden="true"></i></a>
									</div>
								</div>
							</div>
							<h3 class="text-center"><?php echo $dept;?></h3>

						</div>
						<?php
					}
					?>
				</ul>
			</div>
		</div>
	</div>
	<div class="modal-footerr text-center">
		<hr class="white-hr">
		<button type="button" class="btn btn-default font-black" data-dismiss="modal" onclick="gotomeettheteam();">Close</button>
	</div>
	
</div>
