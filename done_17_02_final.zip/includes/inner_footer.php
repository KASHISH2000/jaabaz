<footer id="footer" class="footer-dark text-light container-fluid">
    <div class="footer-inner wrapper row">

        <div class="clearfix">
            <div class="col-md-3 footer-col-3-first">
               <div class="widget">
                   <img src="img/logo_footer2.png" srcset="img/logo_footer2.png 1x, img/logo_footer2.png 2x" alt="Jaabaz" class="footer-logo">
                   <div class="spacer-mini"></div>
                   <ul class="socialmedia-widget hover-fade-1 text-center">
                    <li class="facebook"><a href="https://www.facebook.com/teamjaabaz/" target="_blank"></a></li>
                    <li class="linkedin"><a href="https://www.linkedin.com/company/9241675?trk=prof-exp-company-name" target="_blank"></a></li>
                    <li class="youtube"><a href="https://www.youtube.com/channel/UCQYPdJIlSCqqYTSI9OAZ0OQ" target="_blank"></a></li>
                </ul>
            </div>

            <div class="widget social-footer-div text-center">
                
            </div>

        </div>
        <div class="col-md-6">
         <div class="fb-page" data-href="https://www.facebook.com/teamjaabaz/" data-width="500" data-height="450" data-small-header="false" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="false"><blockquote cite="https://www.facebook.com/teamjaabaz/" class="fb-xfbml-parse-ignore"><a href="https://www.facebook.com/teamjaabaz/">TEAM JAABAZ</a></blockquote></div>
     </div>
     <div class="col-md-2">
      
         <div class="footer-acm-div">
             <a href="https://www.facebook.com/ACM.VITU/" target="_blank">
               <img class="acmlogo-footer" src="img/acm.png">
               <div class="acm-text">&copy; Developed by ACM-VIT</div>
           </a>
       </div>
   </div>
</div>
</div>
</footer>