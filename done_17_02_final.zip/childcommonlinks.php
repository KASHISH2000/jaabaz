 <link rel="apple-touch-icon" href="../img/logo.png">
    <link rel="icon" type="image/png" href="../img/logo.png">
    <meta name="msapplication-TileImage" content="../img/logo.png">
    <link rel="stylesheet" type="text/css" href="../styles/ionicons.min.css">
    <link rel="stylesheet" type="text/css" href="../styles/buttonloader.css">
    <link href="../styles/main.css" rel="stylesheet" />
    <link href="../styles/vendor.css" rel="stylesheet" />
     <link href="../styles/commontochilds.css" rel="stylesheet" />