<div class="modal-content" id="supportus">
	<div class="modal-headerr" style="padding: 10px;">
		<br>
		<button type="button" class="close" data-dismiss="modal" style="color:#fff !important;"><i class="ion-close-round" style="color:#fff !important;"></i>&nbsp;&nbsp;</button>
		<h1 class="modal-title text-center">Support Us</h1>
	</div>
	<div class="modal-body">
		<div class="container">
			<div class="support-text-div col-md-10 col-md-offset-1">
				Team Jaabaz is an advocate of the budding Indian Motorsport Scene. We are a group of engineers working towards innovation in our field. Check out our Sponsorship Brochure.
			</div>
			<div class="col-xs-12">
				<br><br><br>
			</div>
			<div class="brochure-div col-md-6 col-md-offset-3">
				<iframe style="width:100%; height:340px;" src="//e.issuu.com/embed.html#26852532/44370094" frameborder="0" allowfullscreen></iframe>
			</div>
		</div>
	</div>
	<div class="modal-footerr text-center">
		<hr class="white-hr">
		<button type="button" class="btn btn-default font-black" data-dismiss="modal">Close</button>
	</div>
</div>
